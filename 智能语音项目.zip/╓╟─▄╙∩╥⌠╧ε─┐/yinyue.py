#!/usr/bin/env python
# -*- encoding: UTF-8 -*-

import pyaudio
import os
import sys
import yuyinhecheng
import yuyinshibie
CHUNK = 1024
FORMAT = pyaudio.paInt16  # 16位采集
CHANNELS = 1  # 单声道
RATE = 16000  # 采样率
RECORD_SECONDS = 5  # 采样时长 定义为9秒的录音
WAVE_OUTPUT_FILENAME = "./myvoice.pcm"  # 采集声音文件存储路径
token = yuyinshibie.get_access_token()
import pygame


def main():
    volume = 0.5
    pygame.mixer.init()  # 初始化音频部分
    musicpath = []
    num = 0
    login = True
    path = r"/home/pi/Music"  # 音乐文件的路径
    musiclist = os.listdir(path)
    #print(musiclist)
    for musicname in musiclist:  # 将音乐放入列表中
        if 'mp3' in musicname:
            musicpath.append(os.path.join(path, musicname))
        else:
            continue
    #print(musicpath)
    url = "http://tsn.baidu.com/text2audio?tex=可以选择顺序播放，上一曲，下一曲，增大音量，减小音量，暂停播放，继续播放，退出的功能哦&lan=zh&cuid=B8-27-EB-BA-24-14&ctp=1&tok=" + token + "&per=0"
    os.system('mpg123 "%s"' % url)
    while (1):
        os.system('sudo arecord -D "plughw:1" -f S16_LE -r 16000 -d 3 /home/pi/email/pwm.wav')
        info = yuyinshibie.asr_main("/home/pi/email/pwm.wav", token)
        if '稻香'.encode("utf-8") in info:
            pygame.mixer.init()
            filename = '/home/pi/Music/' + '稻香' + '.mp3'
            pygame.mixer.music.load(filename)
            pygame.mixer.music.play(loops=0)
        elif '顺序播放'.encode("utf-8") in info or '顺序'.encode("utf-8") in info:
            pygame.mixer.music.load(musicpath[num])
            pygame.mixer_music.play()
        elif '暂停播放'.encode("utf-8") in info or '暂停'.encode("utf-8") in info:
            pygame.mixer.init()
            pygame.mixer.music.pause()
        elif '继续播放'.encode("utf-8") in info or '继续'.encode("utf-8") in info:
            pygame.mixer.init()
            pygame.mixer.music.unpause()
        elif '下一曲'.encode("utf-8") in info or '下一'.encode("utf-8") in info:
            num += 1
            # pygame.mixer.music.stop()
            pygame.mixer.music.set_endevent(pygame.USEREVENT + 1)
            # pygame.mixer.music.queue(filename)
            pygame.mixer_music.load(musicpath[num])
            pygame.mixer_music.play()
            print("当前正在播放:%s" % musiclist[num])
        elif '上一曲'.encode("utf-8") in info or '上一'.encode("utf-8") in info:
            num -= 1
            pygame.mixer.music.stop()
            pygame.mixer.music.set_endevent(pygame.USEREVENT + 1)
            # pygame.mixer.music.queue(filename)
            pygame.mixer_music.load(musicpath[num])
            pygame.mixer_music.play()
            print("当前正在播放:%s" % musiclist[num])
        elif '加音量'.encode("utf-8") in info or '增大音量'.encode("utf-8") in info:
            if volume + 0.1 > 1:
                url = "http://tsn.baidu.com/text2audio?tex=音量已经最大了&lan=zh&cuid=B8-27-EB-BA-24-14&ctp=1&tok=" + token + "&per=0"
                os.system('mpg123 "%s"' % url)
            else:
                volume += 0.1
                pygame.mixer_music.set_volume(volume)
                print("音量已增大,当前音量为:%.3s" % volume)
                # print("音量已增大,当前音量为:%.3s" % volume)
        elif '减音量'.encode("utf-8") in info or '减小音量'.encode("utf-8") in info:
            if volume - 0.1 < 0:
                url = "http://tsn.baidu.com/text2audio?tex=音量已经最小了&lan=zh&cuid=B8-27-EB-BA-24-14&ctp=1&tok=" + token + "&per=0"
                os.system('mpg123 "%s"' % url)
            else:
                volume -= 0.1
                pygame.mixer_music.set_volume(volume)
                print("音量已减小,当前音量为:%.3s" % volume)
        elif '退出'.encode("utf-8") in info:
            break
        # elif info is not None:



if __name__ == '__main__':
    main()

