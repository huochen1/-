# coding: utf-8

import requests
import json
import sys
reload(sys)
sys.setdefaultencoding("utf-8")


def turling(words):
    Tuling_API_KEY = "3c7731bc61f945b5b3c9635c1b876774"

    body = {"key":Tuling_API_KEY,"info":words.encode("utf-8")}

    url = "http://www.tuling123.com/openapi/api"
    r = requests.post(url,data=body,verify=True)

    if r:
        date = json.loads(r.text)
        print date["text"]
        return date["text"]
    else:
        return None
